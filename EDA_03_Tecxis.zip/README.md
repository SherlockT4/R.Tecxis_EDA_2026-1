# Estructura de datos y algoritmos — Tareas y Prácticas

- Alumno: Roberto Tecxis Hernandez
- Grupo: 03

# Contenido
- `Practica 0/` — Programa en C "Hola Mundo".

---
> Reemplaza los corchetes con tus datos reales antes de subir.
