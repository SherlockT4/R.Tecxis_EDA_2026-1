#include <stdio.h>

int main(void) {
    printf("Hola, mundo\n");
    return 0;
}
